import React from 'react';
import { ScrollView, StyleSheet, ScrollViewProps } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming 
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';

const AnimatedScrollView = Animated.createAnimatedComponent(ScrollView);

type ThemedScrollViewProps = ScrollViewProps & {
  children: React.ReactNode;
};

export default function ThemedScrollView({ children, ...props }: ThemedScrollViewProps) {
  const { isDarkMode } = useTheme();
  
  const animatedStyle = useAnimatedStyle(() => {
    return {
      backgroundColor: withTiming(isDarkMode ? '#1a1a1a' : '#f5f5f5', {
        duration: 300,
      }),
    };
  });
  
  return (
    <AnimatedScrollView
      style={[styles.scrollView, animatedStyle]}
      showsVerticalScrollIndicator={false}
      {...props}
    >
      {children}
    </AnimatedScrollView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
  },
});