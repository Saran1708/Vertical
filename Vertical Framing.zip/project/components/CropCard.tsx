import React from 'react';
import { StyleSheet, TouchableOpacity, Image, View, Text } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  useSharedValue,
  withSpring 
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';

type CropCardProps = {
  name: string;
  image: string;
  description: string;
  onPress: () => void;
};

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function CropCard({ name, image, description, onPress }: CropCardProps) {
  const { isDarkMode } = useTheme();
  const scale = useSharedValue(1);
  
  const handlePressIn = () => {
    scale.value = withSpring(0.97);
  };
  
  const handlePressOut = () => {
    scale.value = withSpring(1);
  };
  
  const animatedCardStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: scale.value }],
      backgroundColor: withTiming(isDarkMode ? '#1E1E1E' : '#ffffff', {
        duration: 300,
      }),
    };
  });
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedDescriptionStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });

  return (
    <AnimatedTouchable
      style={[styles.card, animatedCardStyle]}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      activeOpacity={0.9}
    >
      <Image source={{ uri: image }} style={styles.image} />
      <View style={styles.content}>
        <Animated.Text style={[styles.name, animatedTextStyle]}>
          {name}
        </Animated.Text>
        <Animated.Text style={[styles.description, animatedDescriptionStyle]} numberOfLines={2}>
          {description}
        </Animated.Text>
      </View>
    </AnimatedTouchable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 12,
    marginHorizontal: 16,
    marginVertical: 8,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    flexDirection: 'row',
    height: 100,
  },
  image: {
    width: 100,
    height: 100,
    resizeMode: 'cover',
  },
  content: {
    flex: 1,
    padding: 12,
    justifyContent: 'center',
  },
  name: {
    fontFamily: 'Poppins-Bold',
    fontSize: 16,
    marginBottom: 4,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: 13,
    lineHeight: 18,
  },
});