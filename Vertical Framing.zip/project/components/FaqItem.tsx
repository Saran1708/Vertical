import React, { useState } from 'react';
import { StyleSheet, TouchableOpacity, View, Text } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming, 
  useSharedValue,
  withSpring
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { ChevronDown, ChevronUp } from 'lucide-react-native';

type FaqItemProps = {
  question: string;
  answer: string;
};

export default function FaqItem({ question, answer }: FaqItemProps) {
  const { isDarkMode } = useTheme();
  const [isExpanded, setIsExpanded] = useState(false);
  const rotateChevron = useSharedValue(0);
  const contentHeight = useSharedValue(0);
  
  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
    rotateChevron.value = withSpring(isExpanded ? 0 : 1);
    contentHeight.value = withTiming(isExpanded ? 0 : 1, { duration: 300 });
  };
  
  const animatedCardStyle = useAnimatedStyle(() => {
    return {
      backgroundColor: withTiming(isDarkMode ? '#1E1E1E' : '#ffffff', {
        duration: 300,
      }),
      borderColor: withTiming(isDarkMode ? '#333333' : '#e5e5e5', {
        duration: 300,
      }),
    };
  });
  
  const animatedQuestionStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedAnswerStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
      opacity: contentHeight.value,
      height: contentHeight.value === 0 ? 0 : 'auto',
      overflow: 'hidden',
    };
  });
  
  const chevronStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${rotateChevron.value * 180}deg` }],
    };
  });

  return (
    <Animated.View style={[styles.container, animatedCardStyle]}>
      <TouchableOpacity 
        style={styles.questionContainer} 
        onPress={toggleExpand}
        activeOpacity={0.7}
      >
        <Animated.Text style={[styles.question, animatedQuestionStyle]}>
          {question}
        </Animated.Text>
        <Animated.View style={chevronStyle}>
          <ChevronDown size={20} color={isDarkMode ? '#f5f5f5' : '#121212'} />
        </Animated.View>
      </TouchableOpacity>
      
      {isExpanded && (
        <Animated.Text style={[styles.answer, animatedAnswerStyle]}>
          {answer}
        </Animated.Text>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    marginHorizontal: 16,
    marginVertical: 8,
    padding: 16,
    borderWidth: 1,
  },
  questionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  question: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    flex: 1,
    paddingRight: 8,
  },
  answer: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 22,
    marginTop: 12,
  },
});