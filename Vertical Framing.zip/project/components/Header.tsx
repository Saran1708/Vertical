import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { Sun, Moon } from 'lucide-react-native';
import Animated, { useAnimatedStyle, withTiming } from 'react-native-reanimated';

type HeaderProps = {
  title: string;
};

export default function Header({ title }: HeaderProps) {
  const { isDarkMode, toggleTheme } = useTheme();

  const animatedContainerStyle = useAnimatedStyle(() => {
    return {
      backgroundColor: withTiming(isDarkMode ? '#121212' : '#ffffff', {
        duration: 300,
      }),
      borderBottomColor: withTiming(isDarkMode ? '#333333' : '#e5e5e5', {
        duration: 300,
      }),
    };
  });

  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });

  return (
    <Animated.View style={[styles.container, animatedContainerStyle]}>
      <Animated.Text style={[styles.title, animatedTextStyle]}>
        {title}
      </Animated.Text>
      <TouchableOpacity
        style={styles.themeButton}
        onPress={toggleTheme}
        activeOpacity={0.7}
      >
        {isDarkMode ? (
          <Sun size={24} color="#f5f5f5" />
        ) : (
          <Moon size={24} color="#121212" />
        )}
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
  },
  themeButton: {
    padding: 8,
    borderRadius: 20,
  },
});