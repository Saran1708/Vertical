import { Tabs } from 'expo-router';
import { useTheme } from '@/contexts/ThemeContext';
import { Chrome as Home, Leaf, Building2, CircleHelp as HelpCircle } from 'lucide-react-native';
import { View, Text } from 'react-native';

export default function TabLayout() {
  const { isDarkMode } = useTheme();
  
  const backgroundColor = isDarkMode ? '#1a1a1a' : '#f5f5f5';
  const activeColor = isDarkMode ? '#43bec3' : '#00952e';
  const inactiveColor = isDarkMode ? '#666666' : '#888888';
  const labelColor = isDarkMode ? '#f5f5f5' : '#121212';
  
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: isDarkMode ? '#121212' : '#ffffff',
          borderTopColor: isDarkMode ? '#333333' : '#e5e5e5',
        },
        tabBarActiveTintColor: activeColor,
        tabBarInactiveTintColor: inactiveColor,
        tabBarLabelStyle: {
          fontFamily: 'Poppins-Regular',
          fontSize: 12,
        }
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />
        }}
      />
      <Tabs.Screen
        name="case-studies"
        options={{
          title: 'Case Studies',
          tabBarIcon: ({ color, size }) => <Leaf size={size} color={color} />
        }}
      />
      <Tabs.Screen
        name="companies"
        options={{
          title: 'Companies',
          tabBarIcon: ({ color, size }) => <Building2 size={size} color={color} />
        }}
      />
      <Tabs.Screen
        name="faq"
        options={{
          title: 'FAQ',
          tabBarIcon: ({ color, size }) => <HelpCircle size={size} color={color} />
        }}
      />
    </Tabs>
  );
}