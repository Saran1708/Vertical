import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  FadeInDown
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { useRouter } from 'expo-router';
import Header from '@/components/Header';
import CompanyCard from '@/components/CompanyCard';
import ThemedScrollView from '@/components/ThemedScrollView';

export default function CompaniesScreen() {
  const { isDarkMode } = useTheme();
  const router = useRouter();
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedSubtitleStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });

  const companiesData = [
    {
      id: '1',
      name: 'Urban Kisaan',
      logo: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg',
      location: 'Hyderabad, India',
      specialty: 'Hydroponic farming technology',
    },
    {
      id: '2',
      name: '365D Farms',
      logo: 'https://images.pexels.com/photos/1460036/pexels-photo-1460036.jpeg',
      location: 'Mumbai, India',
      specialty: 'Year-round sustainable growing',
    },
    {
      id: '3',
      name: 'Triton Foodworks',
      logo: 'https://images.pexels.com/photos/207247/pexels-photo-207247.jpeg',
      location: 'Delhi, India',
      specialty: 'Hydroponic and aeroponic systems',
    },
    {
      id: '4',
      name: 'Agrigo',
      logo: 'https://images.pexels.com/photos/974314/pexels-photo-974314.jpeg',
      location: 'Bangalore, India',
      specialty: 'Modular vertical farms',
    },
    {
      id: '5',
      name: 'Cubic Farm Systems',
      logo: 'https://images.pexels.com/photos/2284170/pexels-photo-2284170.jpeg',
      location: 'Vancouver, Canada',
      specialty: 'Automated growing systems',
    },
  ];

  const navigateToCompanyDetails = (companyId: string) => {
    router.push(`/company-details/${companyId}`);
  };

  return (
    <View style={styles.container}>
      <Header title="Leading Companies" />
      
      <ThemedScrollView contentContainerStyle={styles.scrollContent}>
        <Animated.Text 
          style={[styles.introText, animatedSubtitleStyle]}
          entering={FadeInDown.delay(200).duration(800)}
        >
          These innovative companies are pioneering vertical farming technologies and sustainable food production around the world.
        </Animated.Text>
        
        {companiesData.map((company, index) => (
          <Animated.View 
            key={company.id}
            entering={FadeInDown.delay(300 + index * 100).duration(800)}
          >
            <CompanyCard
              name={company.name}
              logo={company.logo}
              location={company.location}
              specialty={company.specialty}
              onPress={() => navigateToCompanyDetails(company.id)}
            />
          </Animated.View>
        ))}
      </ThemedScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingVertical: 16,
    paddingBottom: 24,
  },
  introText: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
});