import React from 'react';
import { View, StyleSheet, Text, Image } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  FadeIn,
  FadeInDown
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import Header from '@/components/Header';
import FarmingTypeCard from '@/components/FarmingTypeCard';
import ThemedScrollView from '@/components/ThemedScrollView';

export default function HomeScreen() {
  const { isDarkMode } = useTheme();
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedSubtitleStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });

  const farmingTypes = [
    {
      id: '1',
      title: 'Hydroponics',
      description: 'Growing plants in nutrient-rich water without soil',
      image: 'https://images.pexels.com/photos/2286776/pexels-photo-2286776.jpeg',
    },
    {
      id: '2',
      title: 'Aeroponics',
      description: 'Plants grown in air or mist environment without soil',
      image: 'https://images.pexels.com/photos/3705338/pexels-photo-3705338.jpeg',
    },
    {
      id: '3',
      title: 'Aquaponics',
      description: 'Combines conventional aquaculture with hydroponics',
      image: 'https://images.pexels.com/photos/3698070/pexels-photo-3698070.jpeg',
    },
  ];

  return (
    <View style={styles.container}>
      <Header title="Vertical Farming" />
      
      <ThemedScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.heroSection}>
          <Animated.Text 
            style={[styles.heading, animatedTextStyle]}
            entering={FadeInDown.delay(100).duration(800)}
          >
            What is Vertical Farming?
          </Animated.Text>
          
          <Image 
            source={{ 
              uri: 'https://images.pexels.com/photos/2132250/pexels-photo-2132250.jpeg'
            }}
            style={styles.heroImage}
          />
          
          <Animated.Text 
            style={[styles.description, animatedSubtitleStyle]}
            entering={FadeInDown.delay(300).duration(800)}
          >
            Vertical farming is the practice of growing crops in vertically stacked layers, 
            often incorporating controlled-environment agriculture, which aims to optimize 
            plant growth, and soilless farming techniques such as hydroponics, aquaponics, 
            and aeroponics.
          </Animated.Text>
        </View>
        
        <Animated.Text 
          style={[styles.sectionTitle, animatedTextStyle]}
          entering={FadeInDown.delay(400).duration(800)}
        >
          Types of Vertical Farming
        </Animated.Text>
        
        {farmingTypes.map((type, index) => (
          <Animated.View 
            key={type.id}
            entering={FadeInDown.delay(500 + index * 100).duration(800)}
          >
            <FarmingTypeCard
              title={type.title}
              description={type.description}
              image={type.image}
              onPress={() => {}}
            />
          </Animated.View>
        ))}
        
        <View style={styles.benefitsSection}>
          <Animated.Text 
            style={[styles.sectionTitle, animatedTextStyle]}
            entering={FadeInDown.delay(800).duration(800)}
          >
            Benefits of Vertical Farming
          </Animated.Text>
          
          <Animated.View 
            style={styles.benefitItem}
            entering={FadeInDown.delay(900).duration(800)}
          >
            <Animated.Text style={[styles.benefitTitle, animatedTextStyle]}>
              Year-round crop production
            </Animated.Text>
            <Animated.Text style={[styles.benefitDescription, animatedSubtitleStyle]}>
              Vertical farming allows for consistent crop production regardless of weather or season.
            </Animated.Text>
          </Animated.View>
          
          <Animated.View 
            style={styles.benefitItem}
            entering={FadeInDown.delay(1000).duration(800)}
          >
            <Animated.Text style={[styles.benefitTitle, animatedTextStyle]}>
              Reduced water usage
            </Animated.Text>
            <Animated.Text style={[styles.benefitDescription, animatedSubtitleStyle]}>
              Uses up to 95% less water than traditional farming methods.
            </Animated.Text>
          </Animated.View>
          
          <Animated.View 
            style={styles.benefitItem}
            entering={FadeInDown.delay(1100).duration(800)}
          >
            <Animated.Text style={[styles.benefitTitle, animatedTextStyle]}>
              No pesticides or herbicides
            </Animated.Text>
            <Animated.Text style={[styles.benefitDescription, animatedSubtitleStyle]}>
              Controlled environment eliminates the need for chemical crop protection.
            </Animated.Text>
          </Animated.View>
        </View>
      </ThemedScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  heroSection: {
    padding: 16,
  },
  heading: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    marginBottom: 16,
  },
  heroImage: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginBottom: 16,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    lineHeight: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
    marginTop: 24,
    marginBottom: 12,
    paddingHorizontal: 16,
  },
  benefitsSection: {
    marginTop: 16,
    paddingHorizontal: 16,
  },
  benefitItem: {
    marginBottom: 16,
  },
  benefitTitle: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    marginBottom: 4,
  },
  benefitDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
  },
});