import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  FadeInDown
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { useRouter } from 'expo-router';
import Header from '@/components/Header';
import CropCard from '@/components/CropCard';
import ThemedScrollView from '@/components/ThemedScrollView';

export default function CaseStudiesScreen() {
  const { isDarkMode } = useTheme();
  const router = useRouter();
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedSubtitleStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });

  const cropsData = [
    {
      id: '1',
      name: 'Strawberry',
      image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg',
      description: 'High-value crop that thrives in vertical farming systems',
    },
    {
      id: '2',
      name: 'Mushroom',
      image: 'https://images.pexels.com/photos/2286333/pexels-photo-2286333.jpeg',
      description: 'Excellent for vertical cultivation due to low light needs',
    },
    {
      id: '3',
      name: 'Turmeric',
      image: 'https://images.pexels.com/photos/4197466/pexels-photo-4197466.jpeg',
      description: 'A healing spice that grows well in controlled environments',
    },
    {
      id: '4',
      name: 'Spinach',
      image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg',
      description: 'Fast-growing leafy green perfect for vertical systems',
    },
    {
      id: '5',
      name: 'Saffron',
      image: 'https://images.pexels.com/photos/9771174/pexels-photo-9771174.jpeg',
      description: 'World\'s most expensive spice, ideal for high-density farming',
    },
  ];

  const navigateToCropDetails = (cropId: string) => {
    router.push(`/crop-details/${cropId}`);
  };

  return (
    <View style={styles.container}>
      <Header title="Case Studies" />
      
      <ThemedScrollView contentContainerStyle={styles.scrollContent}>
        <Animated.Text 
          style={[styles.introText, animatedSubtitleStyle]}
          entering={FadeInDown.delay(200).duration(800)}
        >
          Explore how these crops are revolutionizing vertical farming with their unique characteristics and profitability.
        </Animated.Text>
        
        {cropsData.map((crop, index) => (
          <Animated.View 
            key={crop.id}
            entering={FadeInDown.delay(300 + index * 100).duration(800)}
          >
            <CropCard
              name={crop.name}
              image={crop.image}
              description={crop.description}
              onPress={() => navigateToCropDetails(crop.id)}
            />
          </Animated.View>
        ))}
      </ThemedScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingVertical: 16,
    paddingBottom: 24,
  },
  introText: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
});