import React from 'react';
import { View, StyleSheet, Text } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  FadeInDown 
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import Header from '@/components/Header';
import FaqItem from '@/components/FaqItem';
import ThemedScrollView from '@/components/ThemedScrollView';

export default function FaqScreen() {
  const { isDarkMode } = useTheme();
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedSubtitleStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });

  const faqData = [
    {
      id: '1',
      question: 'What are the advantages of vertical farming?',
      answer: 'Vertical farming offers numerous advantages including year-round crop production regardless of weather conditions, significantly reduced water usage (up to 95% less than traditional farming), elimination of pesticides and herbicides, reduced food miles, and more efficient land use through vertical stacking of growing systems.',
    },
    {
      id: '2',
      question: 'Is vertical farming economically viable?',
      answer: 'Vertical farming can be economically viable, especially for high-value crops and in regions with high land costs, water scarcity, or extreme weather conditions. While initial setup costs are high, operational efficiencies, premium pricing for local produce, and year-round production capability can lead to profitability over time. The economics improve as technology advances and energy costs decrease.',
    },
    {
      id: '3',
      question: 'How does vertical farming impact the environment?',
      answer: 'Vertical farming has several positive environmental impacts including reduced water usage, elimination of agricultural runoff, decreased need for transportation (reduced carbon emissions), no need for pesticides, and reduced land use. However, it does require significant energy for lighting and climate control, which can have environmental impacts depending on the energy source.',
    },
    {
      id: '4',
      question: 'What crops are best suited for vertical farming?',
      answer: 'Crops best suited for vertical farming are typically those with high value, short growth cycles, and compact growth habits. These include leafy greens (lettuce, spinach, kale), herbs (basil, mint, parsley), strawberries, tomatoes, peppers, and certain microgreens. Some facilities are also successfully growing root vegetables and specialty crops like edible flowers.',
    },
    {
      id: '5',
      question: 'What is the difference between hydroponics and aeroponics?',
      answer: 'Hydroponics involves growing plants in nutrient-rich water without soil, with roots submerged in the solution or supported by inert media like rockwool. Aeroponics is a more advanced technique where plant roots are suspended in air and misted with nutrient solution. Aeroponics typically uses less water than hydroponics and provides more oxygen to roots, but requires more precise control systems.',
    },
    {
      id: '6',
      question: 'How much energy does vertical farming use?',
      answer: 'Vertical farms can be energy-intensive, primarily due to artificial lighting requirements and climate control systems. Energy usage varies widely based on the specific growing system, crops, and facility design. Modern vertical farms are increasingly implementing energy-efficient LED lighting, renewable energy sources, and improved system designs to reduce their energy footprint.',
    },
    {
      id: '7',
      question: 'Can vertical farming feed the world?',
      answer: 'While vertical farming alone cannot completely feed the world, it can be an important component of sustainable food systems, especially in urban areas. It excels at producing certain types of fresh produce year-round near population centers, reducing transportation needs and providing fresh food in food deserts. Traditional and vertical farming will likely coexist, each addressing different agricultural needs.',
    },
  ];

  return (
    <View style={styles.container}>
      <Header title="FAQ" />
      
      <ThemedScrollView contentContainerStyle={styles.scrollContent}>
        <Animated.Text 
          style={[styles.introText, animatedSubtitleStyle]}
          entering={FadeInDown.delay(200).duration(800)}
        >
          Find answers to commonly asked questions about vertical farming technologies, benefits, and challenges.
        </Animated.Text>
        
        {faqData.map((faq, index) => (
          <Animated.View 
            key={faq.id}
            entering={FadeInDown.delay(300 + index * 100).duration(800)}
          >
            <FaqItem
              question={faq.question}
              answer={faq.answer}
            />
          </Animated.View>
        ))}
      </ThemedScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingVertical: 16,
    paddingBottom: 24,
  },
  introText: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
});