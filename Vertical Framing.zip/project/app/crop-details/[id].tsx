import React from 'react';
import { View, StyleSheet, Text, Image, TouchableOpacity } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  FadeIn
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft } from 'lucide-react-native';
import ThemedScrollView from '@/components/ThemedScrollView';

export default function CropDetailsScreen() {
  const { isDarkMode } = useTheme();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedSubTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });
  
  const animatedCardStyle = useAnimatedStyle(() => {
    return {
      backgroundColor: withTiming(isDarkMode ? '#1E1E1E' : '#ffffff', {
        duration: 300,
      }),
    };
  });

  // This would be fetched from an API in a real app
  const cropDetails = {
    '1': {
      name: 'Strawberry',
      image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg',
      description: 'Strawberries are one of the most popular and profitable crops in vertical farming. They require less vertical space than many other fruiting plants and produce higher yields per square foot than traditional field cultivation.',
      benefits: [
        'High market value and consumer demand',
        'Year-round production capability',
        'Reduced growing cycle (60-75 days vs. 90+ days in soil)',
        'Less susceptible to pests and diseases in controlled environments'
      ],
      challenges: [
        'Requires precise temperature control (65-75°F optimal)',
        'Needs artificial pollination in indoor environments',
        'Higher light requirements than leafy greens',
        'Careful nutrient management needed for optimal flavor'
      ],
      methods: 'Strawberries grow well in both hydroponic and aeroponic systems. The most common setups are NFT (Nutrient Film Technique) and vertical tower systems. Plants typically need 10-12 hours of light daily with specific spectral requirements to induce flowering and fruiting.',
      case_study: 'Japanese indoor farming company Spread Co. has successfully implemented large-scale vertical farming of strawberries, using a combination of LED lighting and automated systems to produce sweet, consistent berries year-round with 30% less water than traditional methods.'
    },
    '2': {
      name: 'Mushroom',
      image: 'https://images.pexels.com/photos/2286333/pexels-photo-2286333.jpeg',
      description: 'Mushrooms are perfectly suited for vertical farming as they naturally grow in stacked, compact environments and don\'t require light for photosynthesis, making them incredibly energy-efficient to cultivate indoors.',
      benefits: [
        'Low energy requirements (no special lighting needed)',
        'High protein content compared to other vertically farmed crops',
        'Fast growth cycle (many varieties reach harvest in 3-4 weeks)',
        'Capable of growing on agricultural by-products and waste'
      ],
      challenges: [
        'Requires careful humidity and temperature control',
        'Contamination prevention is critical',
        'Some varieties need specific substrate formulations',
        'Spore management for worker safety'
      ],
      methods: 'Mushrooms in vertical farms typically grow on specially formulated substrates in bags or trays stacked vertically. Common varieties include oyster, shiitake, and lion\'s mane mushrooms. Temperature, humidity, and CO2 levels must be carefully controlled, with most mushrooms preferring 80-95% humidity and temperatures between 55-70°F depending on the variety.',
      case_study: 'Smallhold, a Brooklyn-based vertical mushroom farm, has developed modular "minifarms" that can be placed in restaurants and grocery stores, allowing ultra-fresh mushrooms to be harvested on-site. Their centralized technology controls temperature, humidity, and CO2 remotely while reducing transportation needs.'
    },
    '3': {
      name: 'Turmeric',
      image: 'https://images.pexels.com/photos/4197466/pexels-photo-4197466.jpeg',
      description: 'Turmeric, prized for its anti-inflammatory properties and growing popularity in health foods, is increasingly being grown in vertical farms to meet year-round demand and produce a cleaner, more consistent product.',
      benefits: [
        'High market value as a specialty crop',
        'Clean, consistent production without soil contaminants',
        'Controlled growth environment can increase curcumin content',
        'Reduced growing time compared to traditional cultivation'
      ],
      challenges: [
        'Requires deeper growing containers than many vertical farm crops',
        'Takes 7-10 months to mature (longer than most vertical farm crops)',
        'Needs careful light spectrum management for rhizome development',
        'Requires proper spacing for rhizome expansion'
      ],
      methods: 'Turmeric in vertical farms is typically grown using deep hydroponic or container systems. The plants need temperatures between 70-85°F with high humidity (80-90%). Specialized red/blue LED lighting is important for proper rhizome development. Careful nutrient management is essential, with higher potassium levels during the rhizome formation stage.',
      case_study: 'Square Roots, an indoor farming company, has successfully cultivated turmeric in their climate-controlled shipping container farms. Their system maintains precise growing conditions that have yielded turmeric with 12-15% higher curcumin content than field-grown varieties.'
    },
    '4': {
      name: 'Spinach',
      image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg',
      description: 'Spinach is one of the most successful crops in vertical farming systems, valued for its quick growth cycle, nutritional density, and consistent market demand throughout the year.',
      benefits: [
        'Rapid growth cycle (30-45 days from seed to harvest)',
        'High nutritional value and strong market demand',
        'Efficient space utilization (can be grown with minimal vertical spacing)',
        'Excellent candidate for automated harvesting systems'
      ],
      challenges: [
        'Sensitive to heat (prefers cooler temperatures 60-70°F)',
        'Prone to tipburn without proper air circulation',
        'Requires careful nutrient management, especially for nitrogen',
        'Susceptible to certain pathogens in high-humidity environments'
      ],
      methods: 'Spinach thrives in various hydroponic systems, with NFT (Nutrient Film Technique) and DWC (Deep Water Culture) being most common. Optimal pH range is 6.0-7.0, with EC (electrical conductivity) levels between 1.8-2.2 mS/cm. Spinach prefers cooler temperatures and moderate light levels, making it less energy-intensive than some crops.',
      case_study: 'AeroFarms, a leading vertical farming company, has perfected spinach production using their proprietary aeroponic technology. Their system produces pesticide-free spinach with consistent flavor profiles in just 12-14 days compared to 30+ days in field conditions, while using 95% less water.'
    },
    '5': {
      name: 'Saffron',
      image: 'https://images.pexels.com/photos/9771174/pexels-photo-9771174.jpeg',
      description: 'Saffron, the world\'s most expensive spice, is being revolutionized through vertical farming, which allows for controlled blooming cycles and can potentially produce multiple harvests per year instead of the traditional single annual harvest.',
      benefits: [
        'Extremely high market value ($5,000-$10,000 per pound)',
        'Controlled environment can induce multiple flowering cycles per year',
        'Protected from weather-related crop failures',
        'Precise climate control can optimize stigma development'
      ],
      challenges: [
        'Complex growth cycle requiring temperature manipulation',
        'Labor-intensive harvesting process',
        'Requires dormancy period simulation',
        'Specialized knowledge for proper corm management'
      ],
      methods: 'Saffron crocus corms are typically grown in shallow containers with well-draining growing media. The vertical farming approach manipulates temperature cycles to induce dormancy and flowering. Cold treatment (35-40°F) for several weeks followed by warming to 50-60°F can trigger flower production. Harvesting and processing remain largely manual due to the delicate nature of the stigmas.',
      case_study: 'Vertical farming startup Roco Saffron has developed a system that produces saffron year-round by precisely controlling temperature and humidity cycles. Their research has shown that controlled environment agriculture can induce up to three flowering cycles per year from the same corms, compared to the single annual harvest in traditional cultivation.'
    },
  };

  const selectedCrop = cropDetails[id as keyof typeof cropDetails];

  if (!selectedCrop) {
    return (
      <View style={styles.container}>
        <Text>Crop not found</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton} 
          onPress={() => router.back()}
          activeOpacity={0.7}
        >
          <ArrowLeft size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
        </TouchableOpacity>
      </View>
      
      <ThemedScrollView contentContainerStyle={styles.scrollContent}>
        <Image source={{ uri: selectedCrop.image }} style={styles.cropImage} />
        
        <View style={styles.contentContainer}>
          <Animated.Text style={[styles.cropName, animatedTextStyle]}>
            {selectedCrop.name}
          </Animated.Text>
          
          <Animated.Text style={[styles.description, animatedSubTextStyle]}>
            {selectedCrop.description}
          </Animated.Text>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Benefits
            </Animated.Text>
            {selectedCrop.benefits.map((benefit, index) => (
              <View key={index} style={styles.bulletPoint}>
                <Animated.Text style={[styles.bullet, animatedTextStyle]}>•</Animated.Text>
                <Animated.Text style={[styles.bulletText, animatedSubTextStyle]}>
                  {benefit}
                </Animated.Text>
              </View>
            ))}
          </Animated.View>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Challenges
            </Animated.Text>
            {selectedCrop.challenges.map((challenge, index) => (
              <View key={index} style={styles.bulletPoint}>
                <Animated.Text style={[styles.bullet, animatedTextStyle]}>•</Animated.Text>
                <Animated.Text style={[styles.bulletText, animatedSubTextStyle]}>
                  {challenge}
                </Animated.Text>
              </View>
            ))}
          </Animated.View>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Growing Methods
            </Animated.Text>
            <Animated.Text style={[styles.methodText, animatedSubTextStyle]}>
              {selectedCrop.methods}
            </Animated.Text>
          </Animated.View>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Case Study
            </Animated.Text>
            <Animated.Text style={[styles.caseStudyText, animatedSubTextStyle]}>
              {selectedCrop.case_study}
            </Animated.Text>
          </Animated.View>
        </View>
      </ThemedScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  backButton: {
    padding: 8,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  cropImage: {
    width: '100%',
    height: 250,
    resizeMode: 'cover',
  },
  contentContainer: {
    padding: 16,
  },
  cropName: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    marginVertical: 16,
  },
  description: {
    fontFamily: 'Inter-Regular',
    fontSize: 15,
    lineHeight: 24,
    marginBottom: 20,
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
  },
  cardTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 18,
    marginBottom: 12,
  },
  bulletPoint: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  bullet: {
    marginRight: 8,
    fontSize: 16,
  },
  bulletText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  methodText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 22,
  },
  caseStudyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 22,
    fontStyle: 'italic',
  },
});