import React from 'react';
import { View, StyleSheet, Text, Image, TouchableOpacity, Linking } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  withTiming,
  FadeIn
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft, Globe, MapPin, Leaf } from 'lucide-react-native';
import ThemedScrollView from '@/components/ThemedScrollView';

export default function CompanyDetailsScreen() {
  const { isDarkMode } = useTheme();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  const animatedTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#f5f5f5' : '#121212', {
        duration: 300,
      }),
    };
  });
  
  const animatedSubTextStyle = useAnimatedStyle(() => {
    return {
      color: withTiming(isDarkMode ? '#b0b0b0' : '#666666', {
        duration: 300,
      }),
    };
  });
  
  const animatedCardStyle = useAnimatedStyle(() => {
    return {
      backgroundColor: withTiming(isDarkMode ? '#1E1E1E' : '#ffffff', {
        duration: 300,
      }),
    };
  });

  // This would be fetched from an API in a real app
  const companyDetails = {
    '1': {
      name: 'Urban Kisaan',
      logo: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg',
      coverImage: 'https://images.pexels.com/photos/2147029/pexels-photo-2147029.jpeg',
      location: 'Hyderabad, India',
      founded: '2017',
      website: 'https://urbankisaan.com',
      specialty: 'Hydroponic farming technology',
      description: 'Urban Kisaan is pioneering vertical farming in India, focusing on hydroponics technology to grow pesticide-free vegetables and herbs. Their patented vertical farming methods use 95% less water than conventional agriculture while producing higher yields.',
      approach: 'The company utilizes a combination of deep water culture and nutrient film technique systems, enhanced with proprietary IoT sensors and AI-based monitoring. Their climate-controlled farms operate in both rural and urban settings, with small-format stores that allow customers to purchase produce directly from the growing environment.',
      impact: 'Urban Kisaan has established over 30 farms across India, producing more than 50 varieties of vegetables and herbs. Their farming methods reduce water usage by 95% compared to traditional agriculture while eliminating chemical pesticides and fertilizers. The company has helped train over 1,000 farmers in modern hydroponic techniques.',
      products: [
        'Leafy greens (spinach, lettuce, kale)',
        'Herbs (basil, mint, coriander)',
        'Microgreens',
        'Hydroponic home growing kits'
      ]
    },
    '2': {
      name: '365D Farms',
      logo: 'https://images.pexels.com/photos/1460036/pexels-photo-1460036.jpeg',
      coverImage: 'https://images.pexels.com/photos/3656596/pexels-photo-3656596.jpeg',
      location: 'Mumbai, India',
      founded: '2018',
      website: 'https://365dfarms.com',
      specialty: 'Year-round sustainable growing',
      description: '365D Farms focuses on creating year-round growing systems that provide consistent, high-quality produce regardless of seasonal constraints. They specialize in controlled environment agriculture that combines vertical farming with renewable energy solutions.',
      approach: 'The company has developed a modular vertical farming system that integrates solar power and water recycling. Their multi-layer cultivation approach optimizes space while their proprietary lighting systems reduce energy consumption. All farms use organic nutrients and compostable packaging for a fully sustainable operation.',
      impact: '365D Farms currently operates 12 facilities across western India, producing food 365 days a year regardless of monsoon seasons or drought conditions. Their systems use 90% less water than conventional farming while eliminating transportation emissions through hyperlocal distribution networks.',
      products: [
        'Premium culinary herbs',
        'Specialty lettuces',
        'Edible flowers',
        'Vertical farming consulting services'
      ]
    },
    '3': {
      name: 'Triton Foodworks',
      logo: 'https://images.pexels.com/photos/207247/pexels-photo-207247.jpeg',
      coverImage: 'https://images.pexels.com/photos/3722573/pexels-photo-3722573.jpeg',
      location: 'Delhi, India',
      founded: '2014',
      website: 'https://tritonfoodworks.com',
      specialty: 'Hydroponic and aeroponic systems',
      description: 'Triton Foodworks is one of India\'s earliest commercial hydroponic farming companies. They design, build and operate soilless farms using both hydroponic and aeroponic technologies, focusing on resource efficiency and high-quality produce.',
      approach: 'The company has developed scalable farming solutions ranging from small rooftop systems to large commercial operations. Their technology stack includes automated nutrient delivery, environmental controls, and data analytics for yield optimization. Triton emphasizes food safety through HACCP-compliant growing environments and traceability systems.',
      impact: 'Since founding, Triton Foodworks has built over 150,000 square feet of hydroponic growing space. Their systems reduce water usage by up to 98% while increasing yields by 30-40% compared to conventional agriculture. The company also trains young entrepreneurs and farmers in hydroponic farming techniques.',
      products: [
        'Fresh vegetables and herbs',
        'Turnkey hydroponic system installations',
        'Consulting services',
        'Hydroponic supplies and nutrients'
      ]
    },
    '4': {
      name: 'Agrigo',
      logo: 'https://images.pexels.com/photos/974314/pexels-photo-974314.jpeg',
      coverImage: 'https://images.pexels.com/photos/3689375/pexels-photo-3689375.jpeg',
      location: 'Bangalore, India',
      founded: '2019',
      website: 'https://agrigo.in',
      specialty: 'Modular vertical farms',
      description: 'Agrigo specializes in container-based vertical farming solutions that bring agriculture to urban environments. Their modular systems can be deployed in various settings, from residential buildings to corporate campuses, creating hyperlocal food production networks.',
      approach: 'The company transforms shipping containers into fully automated vertical farms using hydroponics and LED lighting. Each 40-foot container can produce the equivalent of 3-5 acres of traditional farmland. Their systems are remotely monitored and can be managed through a smartphone app, making urban farming accessible to non-specialists.',
      impact: 'Agrigo has deployed over 25 container farms across southern India, primarily in urban food deserts. Their systems reduce last-mile transportation emissions while creating agricultural opportunities in densely populated areas. The company has partnered with several restaurants and hotels to create "farm-to-table" operations with zero food miles.',
      products: [
        'Modular container farms',
        'Urban farming consultation',
        'Farm management software',
        'Fresh hyperlocal produce'
      ]
    },
    '5': {
      name: 'Cubic Farm Systems',
      logo: 'https://images.pexels.com/photos/2284170/pexels-photo-2284170.jpeg',
      coverImage: 'https://images.pexels.com/photos/4911697/pexels-photo-4911697.jpeg',
      location: 'Vancouver, Canada',
      founded: '2015',
      website: 'https://cubicfarms.com',
      specialty: 'Automated growing systems',
      description: 'Cubic Farm Systems has developed proprietary vertical farming technology that uses automated, rotating growing surfaces to maximize efficiency. Their systems are designed for commercial-scale operations that can operate in any climate condition.',
      approach: 'The company\'s patented "Crop Motion" technology moves plants through the growing environment, ensuring uniform access to light, water, and nutrients. Their automated systems require minimal human intervention while collecting comprehensive data for continuous improvement. Cubic Farms also produces specialized modules for animal feed production alongside fresh produce.',
      impact: 'Cubic Farm Systems technology has been deployed in 15 countries, demonstrating viability in diverse climates from desert to arctic conditions. Their systems reduce water usage by 95% and land requirements by 99% compared to field agriculture. The company\'s livestock feed system can replace 500 acres of field-grown feed with a single module.',
      products: [
        'Commercial-scale vertical farming systems',
        'Automated livestock feed growing machines',
        'System monitoring software',
        'Facility design services'
      ]
    },
  };

  const selectedCompany = companyDetails[id as keyof typeof companyDetails];

  if (!selectedCompany) {
    return (
      <View style={styles.container}>
        <Text>Company not found</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton} 
          onPress={() => router.back()}
          activeOpacity={0.7}
        >
          <ArrowLeft size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
        </TouchableOpacity>
      </View>
      
      <ThemedScrollView contentContainerStyle={styles.scrollContent}>
        <Image source={{ uri: selectedCompany.coverImage }} style={styles.coverImage} />
        
        <View style={styles.logoContainer}>
          <Image source={{ uri: selectedCompany.logo }} style={styles.logo} />
        </View>
        
        <View style={styles.contentContainer}>
          <Animated.Text style={[styles.companyName, animatedTextStyle]}>
            {selectedCompany.name}
          </Animated.Text>
          
          <View style={styles.infoRow}>
            <View style={styles.infoItem}>
              <MapPin size={16} color={isDarkMode ? '#b0b0b0' : '#666666'} />
              <Animated.Text style={[styles.infoText, animatedSubTextStyle]}>
                {selectedCompany.location}
              </Animated.Text>
            </View>
            
            <View style={styles.infoItem}>
              <Leaf size={16} color={isDarkMode ? '#b0b0b0' : '#666666'} />
              <Animated.Text style={[styles.infoText, animatedSubTextStyle]}>
                Founded: {selectedCompany.founded}
              </Animated.Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.websiteButton}
            onPress={() => Linking.openURL(selectedCompany.website)}
          >
            <Globe size={16} color="#ffffff" />
            <Text style={styles.websiteButtonText}>Visit Website</Text>
          </TouchableOpacity>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              About
            </Animated.Text>
            <Animated.Text style={[styles.cardText, animatedSubTextStyle]}>
              {selectedCompany.description}
            </Animated.Text>
          </Animated.View>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Approach
            </Animated.Text>
            <Animated.Text style={[styles.cardText, animatedSubTextStyle]}>
              {selectedCompany.approach}
            </Animated.Text>
          </Animated.View>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Products & Services
            </Animated.Text>
            {selectedCompany.products.map((product, index) => (
              <View key={index} style={styles.bulletPoint}>
                <Animated.Text style={[styles.bullet, animatedTextStyle]}>•</Animated.Text>
                <Animated.Text style={[styles.bulletText, animatedSubTextStyle]}>
                  {product}
                </Animated.Text>
              </View>
            ))}
          </Animated.View>
          
          <Animated.View style={[styles.card, animatedCardStyle]}>
            <Animated.Text style={[styles.cardTitle, animatedTextStyle]}>
              Impact
            </Animated.Text>
            <Animated.Text style={[styles.cardText, animatedSubTextStyle]}>
              {selectedCompany.impact}
            </Animated.Text>
          </Animated.View>
        </View>
      </ThemedScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    position: 'absolute',
    zIndex: 10,
    top: 0,
    left: 0,
    right: 0,
  },
  backButton: {
    padding: 8,
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 20,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  coverImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: -40,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  contentContainer: {
    padding: 16,
  },
  companyName: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    textAlign: 'center',
    marginVertical: 8,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 8,
  },
  infoText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    marginLeft: 4,
  },
  websiteButton: {
    backgroundColor: '#00952e',
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginBottom: 20,
    alignSelf: 'center',
  },
  websiteButtonText: {
    color: '#ffffff',
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    marginLeft: 6,
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
  },
  cardTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 18,
    marginBottom: 12,
  },
  cardText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 22,
  },
  bulletPoint: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  bullet: {
    marginRight: 8,
    fontSize: 16,
  },
  bulletText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
});