/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./components/**/*.{js,jsx,ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#e6f4ea',
          100: '#cce9d5',
          200: '#99d4ab',
          300: '#66bf82',
          400: '#33aa58',
          500: '#00952e',
          600: '#007725',
          700: '#00591c',
          800: '#003c12',
          900: '#001e09',
        },
        secondary: {
          50: '#ecf8f9',
          100: '#d9f2f3',
          200: '#b4e5e7',
          300: '#8ed8db',
          400: '#69cbcf',
          500: '#43bec3',
          600: '#36989c',
          700: '#297275',
          800: '#1b4c4e',
          900: '#0e2627',
        },
        accent: {
          50: '#fff8e6',
          100: '#fff2cc',
          200: '#ffe599',
          300: '#ffd866',
          400: '#ffcb33',
          500: '#ffbe00',
          600: '#cc9800',
          700: '#997200',
          800: '#664c00',
          900: '#332600',
        },
        surface: {
          light: '#ffffff',
          dark: '#121212',
        },
        background: {
          light: '#f5f5f5',
          dark: '#1a1a1a',
        },
        text: {
          light: '#121212',
          dark: '#f5f5f5',
        },
      },
      fontFamily: {
        'poppins': ['Poppins-Regular', 'Poppins', 'sans-serif'],
        'poppins-bold': ['Poppins-Bold', 'Poppins', 'sans-serif'],
        'poppins-light': ['Poppins-Light', 'Poppins', 'sans-serif'],
        'inter': ['Inter-Regular', 'Inter', 'sans-serif'],
        'inter-bold': ['Inter-Bold', 'Inter', 'sans-serif'],
        'inter-light': ['Inter-Light', 'Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};