import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { ChevronDown, ChevronUp, ChevronLeft } from 'lucide-react-native';
import Animated, { FadeIn, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';

const faqs = [
  {
    id: '1',
    question: 'What is vertical farming?',
    answer: 'Vertical farming is the practice of growing crops in vertically stacked layers, often incorporating controlled-environment agriculture, which aims to optimize plant growth, and soilless farming techniques such as hydroponics, aquaponics, and aeroponics. The primary goal is to maximize productivity in a limited space.'
  },
  {
    id: '2',
    question: 'What are the benefits of vertical farming?',
    answer: 'Vertical farming offers numerous benefits including year-round crop production, weather independence, reduced water usage (up to 95% less than traditional farming), minimal land use, reduced transportation costs, and elimination of agricultural runoff. It also allows for pesticide-free growing and often results in higher nutritional value.'
  },
  {
    id: '3',
    question: 'How does vertical farming contribute to sustainability?',
    answer: 'Vertical farming contributes to sustainability by reducing water consumption, eliminating agricultural runoff, decreasing reliance on fossil fuels, preventing deforestation for agricultural land, and reducing carbon emissions from transportation as farms can be located closer to urban centers.'
  },
  {
    id: '4',
    question: 'What crops are suitable for vertical farming?',
    answer: 'Crops best suited for vertical farming include leafy greens (lettuce, kale, spinach), herbs (basil, mint, parsley), strawberries, tomatoes, peppers, and certain microgreens. These plants have shorter growth cycles, are relatively lightweight, and have high market value, making them economically viable for vertical farming.'
  },
  {
    id: '5',
    question: 'Is vertical farming economically viable?',
    answer: 'The economic viability of vertical farming depends on various factors including energy costs, labor expenses, initial investment, crop selection, and market prices. While startup costs can be high, advances in LED technology, automation, and renewable energy are making vertical farming increasingly profitable, especially for high-value crops in urban markets.'
  },
  {
    id: '6',
    question: 'How does GrowVert help with vertical farming?',
    answer: 'GrowVert provides comprehensive resources, technology solutions, and expertise to help both new and established vertical farmers. Our services include farm design consultation, crop selection guidance, technological infrastructure setup, training programs, and ongoing support to maximize yields and profitability in vertical farming operations.'
  },
];

function FAQItem({ item, isLast }: { item: typeof faqs[0]; isLast: boolean }) {
  const [expanded, setExpanded] = useState(false);
  const expandAnimation = useSharedValue(0);
  
  const toggleExpand = () => {
    setExpanded(!expanded);
    expandAnimation.value = withTiming(expanded ? 0 : 1, { duration: 300 });
  };
  
  const contentStyle = useAnimatedStyle(() => {
    return {
      height: expandAnimation.value === 0 ? 0 : 'auto',
      opacity: expandAnimation.value,
      overflow: 'hidden',
    };
  });
  
  const iconStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${expandAnimation.value * 180}deg` }],
    };
  });
  
  return (
    <Animated.View 
      entering={FadeIn.duration(500).delay(Number(item.id) * 100)}
      style={[
        styles.faqItem,
        isLast ? null : styles.faqItemBorder
      ]}
    >
      <Pressable
        style={styles.faqQuestion}
        onPress={toggleExpand}
        android_ripple={{ color: 'rgba(0, 0, 0, 0.05)' }}
      >
        <Text style={styles.questionText}>{item.question}</Text>
        <Animated.View style={iconStyle}>
          {expanded ? (
            <ChevronUp size={20} color="#333333" />
          ) : (
            <ChevronDown size={20} color="#333333" />
          )}
        </Animated.View>
      </Pressable>
      
      <Animated.View style={[styles.faqAnswer, contentStyle]}>
        <Text style={styles.answerText}>{item.answer}</Text>
      </Animated.View>
    </Animated.View>
  );
}

export default function FAQScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ChevronLeft size={24} color="#333333" />
        </Pressable>
        <Text style={styles.headerTitle}>Frequently Asked Questions</Text>
        <View style={styles.placeholderView} />
      </View>
      
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.introText}>
          Find answers to common questions about vertical farming and how GrowVert can help you get started.
        </Text>
        
        <View style={styles.faqContainer}>
          {faqs.map((faq, index) => (
            <FAQItem 
              key={faq.id} 
              item={faq} 
              isLast={index === faqs.length - 1}
            />
          ))}
        </View>
        
        <View style={styles.contactSection}>
          <Text style={styles.contactTitle}>Still have questions?</Text>
          <Text style={styles.contactText}>
            If you couldn't find the answer to your question, please contact our support team for assistance.
          </Text>
          <Pressable style={styles.contactButton}>
            <Text style={styles.contactButtonText}>Contact Support</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 48,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    textAlign: 'center',
  },
  placeholderView: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  introText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
    marginBottom: 24,
  },
  faqContainer: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  faqItem: {
    paddingVertical: 12,
  },
  faqItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  faqQuestion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  questionText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#333333',
    flex: 1,
  },
  faqAnswer: {
    paddingTop: 8,
    paddingBottom: 4,
  },
  answerText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    lineHeight: 22,
  },
  contactSection: {
    backgroundColor: '#EBF9F1',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
  },
  contactTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 8,
  },
  contactText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 20,
  },
  contactButton: {
    backgroundColor: '#98D8AA',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  contactButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#FFFFFF',
  },
});