import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, Pressable, ActivityIndicator, Dimensions } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { ChevronLeft, Thermometer, Ruler, Calendar, DollarSign, Leaf, Droplets, Sun } from 'lucide-react-native';
import Animated, { FadeIn, FadeInRight, FadeInLeft } from 'react-native-reanimated';
import { crops } from '@/data/crops';

const { width } = Dimensions.get('window');

export default function CropDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [crop, setCrop] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      const foundCrop = crops.find(c => c.id === id);
      setCrop(foundCrop);
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [id]);
  
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#98D8AA" />
      </View>
    );
  }
  
  if (!crop) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Crop not found</Text>
        <Pressable 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </Pressable>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Pressable 
            style={styles.backButtonContainer}
            onPress={() => router.back()}
          >
            <ChevronLeft size={24} color="#333333" />
          </Pressable>
        </View>
        
        <Image
          source={{ uri: crop.image }}
          style={styles.cropImage}
          resizeMode="cover"
        />
        
        <Animated.View 
          entering={FadeIn.duration(600).delay(200)}
          style={styles.cropInfo}
        >
          <Text style={styles.cropName}>{crop.name}</Text>
          <Text style={styles.scientificName}>{crop.scientificName}</Text>
          
          <Text style={styles.description}>{crop.description}</Text>
          
          <View style={styles.specGrid}>
            <Animated.View 
              entering={FadeInLeft.duration(600).delay(400)}
              style={styles.specCard}
            >
              <View style={[styles.iconContainer, styles.iconTemperature]}>
                <Thermometer size={20} color="#F97316" />
              </View>
              <Text style={styles.specLabel}>Temperature</Text>
              <Text style={styles.specValue}>{crop.temperature}</Text>
            </Animated.View>
            
            <Animated.View 
              entering={FadeInRight.duration(600).delay(400)}
              style={styles.specCard}
            >
              <View style={[styles.iconContainer, styles.iconHeight]}>
                <Ruler size={20} color="#8B5CF6" />
              </View>
              <Text style={styles.specLabel}>Height</Text>
              <Text style={styles.specValue}>{crop.height}</Text>
            </Animated.View>
            
            <Animated.View 
              entering={FadeInLeft.duration(600).delay(600)}
              style={styles.specCard}
            >
              <View style={[styles.iconContainer, styles.iconLifespan]}>
                <Calendar size={20} color="#EC4899" />
              </View>
              <Text style={styles.specLabel}>Lifespan</Text>
              <Text style={styles.specValue}>{crop.lifespan}</Text>
            </Animated.View>
            
            <Animated.View 
              entering={FadeInRight.duration(600).delay(600)}
              style={styles.specCard}
            >
              <View style={[styles.iconContainer, styles.iconMarket]}>
                <DollarSign size={20} color="#10B981" />
              </View>
              <Text style={styles.specLabel}>Market Value</Text>
              <Text style={styles.specValue}>{crop.marketValue}</Text>
            </Animated.View>
          </View>
          
          <Animated.View
            entering={FadeIn.duration(600).delay(800)}
            style={styles.section}
          >
            <Text style={styles.sectionTitle}>Growing Requirements</Text>
            
            <View style={styles.requirementCard}>
              <View style={styles.requirementRow}>
                <View style={styles.requirementIcon}>
                  <Leaf size={18} color="#98D8AA" />
                </View>
                <View>
                  <Text style={styles.requirementLabel}>Nutrients</Text>
                  <Text style={styles.requirementValue}>{crop.growingRequirements.nutrients}</Text>
                </View>
              </View>
              
              <View style={styles.requirementRow}>
                <View style={styles.requirementIcon}>
                  <Droplets size={18} color="#60A5FA" />
                </View>
                <View>
                  <Text style={styles.requirementLabel}>Water</Text>
                  <Text style={styles.requirementValue}>{crop.growingRequirements.water}</Text>
                </View>
              </View>
              
              <View style={styles.requirementRow}>
                <View style={styles.requirementIcon}>
                  <Sun size={18} color="#FBBF24" />
                </View>
                <View>
                  <Text style={styles.requirementLabel}>Light</Text>
                  <Text style={styles.requirementValue}>{crop.growingRequirements.light}</Text>
                </View>
              </View>
            </View>
          </Animated.View>
          
          <Animated.View
            entering={FadeIn.duration(600).delay(1000)}
            style={styles.section}
          >
            <Text style={styles.sectionTitle}>Usage</Text>
            <Text style={styles.usageText}>{crop.usage}</Text>
          </Animated.View>
          
          <Animated.View
            entering={FadeIn.duration(600).delay(1200)}
            style={styles.section}
          >
            <Text style={styles.sectionTitle}>Origin</Text>
            <Text style={styles.originText}>{crop.origin}</Text>
          </Animated.View>
        </Animated.View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  errorText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 18,
    color: '#EF4444',
    marginBottom: 16,
  },
  backButton: {
    backgroundColor: '#98D8AA',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  backButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 32,
  },
  header: {
    position: 'absolute',
    top: 48,
    left: 16,
    zIndex: 10,
  },
  backButtonContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cropImage: {
    width: '100%',
    height: 300,
  },
  cropInfo: {
    padding: 16,
  },
  cropName: {
    fontFamily: 'Poppins-Bold',
    fontSize: 28,
    color: '#333333',
    marginBottom: 4,
  },
  scientificName: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#808080',
    fontStyle: 'italic',
    marginBottom: 16,
  },
  description: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
    marginBottom: 24,
  },
  specGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  specCard: {
    width: (width - 48) / 2,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconTemperature: {
    backgroundColor: '#FEF3F2',
  },
  iconHeight: {
    backgroundColor: '#F3F0FF',
  },
  iconLifespan: {
    backgroundColor: '#FCE7F3',
  },
  iconMarket: {
    backgroundColor: '#ECFDF5',
  },
  specLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  specValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333333',
  },
  section: {
    marginTop: 8,
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 12,
  },
  requirementCard: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
  },
  requirementRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  requirementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  requirementLabel: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#666666',
    marginBottom: 2,
  },
  requirementValue: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#333333',
  },
  usageText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
  },
  originText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
  },
});