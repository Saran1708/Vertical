import React from 'react';
import { View, Text, StyleSheet, Pressable, Image, Dimensions } from 'react-native';
import { router } from 'expo-router';
import Header from '@/components/Header';
import Animated, { FadeInUp, Layout } from 'react-native-reanimated';
import { ArrowUpRight, MapPin } from 'lucide-react-native';
import { companies } from '@/data/companies';

export default function CompaniesScreen() {
  return (
    <View style={styles.container}>
      <Header title="Companies" />
      
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {companies.map((company, index) => (
          <Animated.View
            key={company.id}
            entering={FadeInUp.delay(index * 150).duration(500)}
            layout={Layout.springify()}
          >
            <Pressable 
              style={styles.companyCard}
              onPress={() => router.push({ pathname: '/(app)/company/[id]', params: { id: company.id } })}
              android_ripple={{ color: 'rgba(0, 0, 0, 0.1)' }}
            >
              <Image
                source={{ uri: company.logo }}
                style={styles.companyLogo}
                resizeMode="cover"
              />
              <View style={styles.companyInfo}>
                <Text style={styles.companyName}>{company.name}</Text>
                
                <View style={styles.locationContainer}>
                  <MapPin size={14} color="#808080" />
                  <Text style={styles.locationText}>{company.location}</Text>
                </View>
                
                <Text style={styles.companyDescription} numberOfLines={3}>
                  {company.description}
                </Text>
                
                <View style={styles.seeMoreContainer}>
                  <Text style={styles.seeMoreText}>See More</Text>
                  <ArrowUpRight size={16} color="#98D8AA" />
                </View>
              </View>
            </Pressable>
          </Animated.View>
        ))}
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  companyCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  companyLogo: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 16,
  },
  companyInfo: {
    flex: 1,
  },
  companyName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333333',
    marginBottom: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  locationText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#808080',
    marginLeft: 4,
  },
  companyDescription: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    marginBottom: 8,
    lineHeight: 20,
  },
  seeMoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seeMoreText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#98D8AA',
    marginRight: 4,
  },
});