import React, { useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, Pressable, Dimensions } from 'react-native';
import { router } from 'expo-router';
import { ArrowRight, Leaf, Droplets, Sun } from 'lucide-react-native';
import Header from '@/components/Header';
import Animated, {
  useAnimatedScrollHandler,
  useSharedValue,
  useAnimatedStyle,
  interpolate,
  Extrapolate,
  withSpring,
  FadeIn,
  FadeInDown,
  FadeInUp
} from 'react-native-reanimated';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 48;

const farmingMethods = [
  {
    id: '1',
    title: 'Hydroponics',
    description: 'Growing plants without soil, using mineral nutrient solutions in water.',
    icon: 'droplets',
    color: '#EBF9F1',
    accent: '#98D8AA',
  },
  {
    id: '2',
    title: 'Aeroponics',
    description: 'Growing plants in an air or mist environment without soil or water.',
    icon: 'leaf',
    color: '#F0F7FF',
    accent: '#93C5FD',
  },
  {
    id: '3',
    title: 'Aquaponics',
    description: 'System that combines aquaculture with hydroponics in a symbiotic environment.',
    icon: 'sun',
    color: '#FEF3E7',
    accent: '#FDBA74',
  },
];

export default function HomeScreen() {
  const scrollY = useSharedValue(0);
  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  const renderIcon = (iconName: string, color: string) => {
    switch (iconName) {
      case 'droplets':
        return <Droplets size={32} color={color} />;
      case 'leaf':
        return <Leaf size={32} color={color} />;
      case 'sun':
        return <Sun size={32} color={color} />;
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <Header />
      
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
      >
        <Animated.View 
          entering={FadeIn.duration(800).delay(200)}
          style={styles.hero}
        >
          <Image
            source={{ uri: 'https://images.pexels.com/photos/2284170/pexels-photo-2284170.jpeg' }}
            style={styles.heroImage}
            resizeMode="cover"
          />
          <View style={styles.heroContent}>
            <Text style={styles.heroTitle}>Revolutionary Vertical Farming</Text>
            <Text style={styles.heroSubtitle}>
              Sustainable farming for the future. Maximize yields with minimal resources.
            </Text>
            <Pressable 
              style={styles.heroButton}
              onPress={() => router.push('/(app)/(tabs)/crops')}
            >
              <Text style={styles.heroButtonText}>Get Started</Text>
              <ArrowRight size={18} color="#FFFFFF" />
            </Pressable>
          </View>
        </Animated.View>
        
        <View style={styles.sectionContainer}>
          <Animated.Text 
            entering={FadeInUp.duration(600).delay(400)}
            style={styles.sectionTitle}
          >
            Vertical Farming Methods
          </Animated.Text>
          
          {farmingMethods.map((method, index) => (
            <Animated.View
              key={method.id}
              entering={FadeInDown.duration(600).delay(600 + index * 200)}
              style={[
                styles.card,
                { backgroundColor: method.color }
              ]}
            >
              <View style={[styles.iconContainer, { backgroundColor: method.accent + '20' }]}>
                {renderIcon(method.icon, method.accent)}
              </View>
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>{method.title}</Text>
                <Text style={styles.cardDescription}>{method.description}</Text>
              </View>
            </Animated.View>
          ))}
        </View>
        
        <Animated.View 
          entering={FadeInUp.duration(600).delay(1200)}
          style={styles.ctaContainer}
        >
          <Text style={styles.ctaTitle}>Ready to grow?</Text>
          <Text style={styles.ctaText}>
            Explore our collection of cash crops suitable for vertical farming.
          </Text>
          <Pressable 
            style={styles.ctaButton}
            onPress={() => router.push('/(app)/(tabs)/crops')}
          >
            <Text style={styles.ctaButtonText}>Explore Cash Crops</Text>
            <ArrowRight size={18} color="#FFFFFF" />
          </Pressable>
        </Animated.View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  hero: {
    height: 340,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  heroImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  heroContent: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    padding: 24,
    justifyContent: 'flex-end',
  },
  heroTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 28,
    color: '#FFFFFF',
    marginBottom: 8,
  },
  heroSubtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 16,
    lineHeight: 24,
  },
  heroButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#98D8AA',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  heroButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#FFFFFF',
    marginRight: 8,
  },
  sectionContainer: {
    marginTop: 24,
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: '#333333',
    marginBottom: 16,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 4,
  },
  cardDescription: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    lineHeight: 20,
  },
  ctaContainer: {
    padding: 24,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  ctaTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: '#333333',
    marginBottom: 8,
    textAlign: 'center',
  },
  ctaText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 20,
  },
  ctaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#98D8AA',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  ctaButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#FFFFFF',
    marginRight: 8,
  },
});