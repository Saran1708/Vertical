import React from 'react';
import { View, Text, StyleSheet, Pressable, Image, Dimensions, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { ArrowUpRight } from 'lucide-react-native';
import Header from '@/components/Header';
import Animated, { FadeInUp, Layout } from 'react-native-reanimated';
import { crops } from '@/data/crops';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 48) / 2;

export default function CropsScreen() {
  return (
    <View style={styles.container}>
      <Header title="Cash Crops" />
      
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.cropGrid}>
          {crops.map((crop, index) => (
            <Animated.View
              key={crop.id}
              entering={FadeInUp.delay(index * 100).duration(500)}
              layout={Layout.springify()}
              style={styles.cropCardContainer}
            >
              <Pressable 
                style={styles.cropCard}
                onPress={() => router.push({ pathname: '/(app)/crop/[id]', params: { id: crop.id } })}
                android_ripple={{ color: 'rgba(0, 0, 0, 0.1)' }}
              >
                <Image
                  source={{ uri: crop.image }}
                  style={styles.cropImage}
                  resizeMode="cover"
                />
                <View style={styles.cropCardContent}>
                  <Text style={styles.cropName}>{crop.name}</Text>
                  <Text style={styles.cropDescription} numberOfLines={2}>
                    {crop.shortDescription}
                  </Text>
                  <View style={styles.knowMoreContainer}>
                    <Text style={styles.knowMoreText}>Know More</Text>
                    <ArrowUpRight size={16} color="#98D8AA" />
                  </View>
                </View>
              </Pressable>
            </Animated.View>
          ))}
        </View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  cropGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  cropCardContainer: {
    width: CARD_WIDTH,
    marginBottom: 16,
  },
  cropCard: {
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cropImage: {
    width: '100%',
    height: 140,
  },
  cropCardContent: {
    padding: 12,
  },
  cropName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333333',
    marginBottom: 4,
  },
  cropDescription: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#666666',
    marginBottom: 8,
    lineHeight: 16,
  },
  knowMoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  knowMoreText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#98D8AA',
    marginRight: 4,
  },
});