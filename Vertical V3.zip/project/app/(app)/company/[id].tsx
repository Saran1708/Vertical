import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, Pressable, ActivityIndicator, Linking } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { ChevronLeft, MapPin, Globe, ChartBar as BarChart, Building2 } from 'lucide-react-native';
import Animated, { FadeIn, FadeInUp } from 'react-native-reanimated';
import { companies } from '@/data/companies';

export default function CompanyDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [company, setCompany] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      const foundCompany = companies.find(c => c.id === id);
      setCompany(foundCompany);
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [id]);
  
  const handleOpenWebsite = (url: string) => {
    Linking.openURL(url).catch(err => {
      console.error('Failed to open URL:', err);
    });
  };
  
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#98D8AA" />
      </View>
    );
  }
  
  if (!company) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Company not found</Text>
        <Pressable 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </Pressable>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Pressable 
            style={styles.backButtonContainer}
            onPress={() => router.back()}
          >
            <ChevronLeft size={24} color="#333333" />
          </Pressable>
        </View>
        
        <Animated.View 
          entering={FadeIn.duration(600)}
          style={styles.companyHeader}
        >
          <Image
            source={{ uri: company.heroImage }}
            style={styles.heroImage}
            resizeMode="cover"
          />
          
          <View style={styles.companyLogo}>
            <Image
              source={{ uri: company.logo }}
              style={styles.logoImage}
              resizeMode="cover"
            />
          </View>
        </Animated.View>
        
        <Animated.View 
          entering={FadeInUp.duration(600).delay(300)}
          style={styles.companyInfo}
        >
          <Text style={styles.companyName}>{company.name}</Text>
          
          <View style={styles.locationContainer}>
            <MapPin size={16} color="#808080" />
            <Text style={styles.locationText}>{company.location}</Text>
          </View>
          
          <Text style={styles.companyDescription}>{company.description}</Text>
          
          <Pressable 
            style={styles.websiteButton}
            onPress={() => handleOpenWebsite(company.website)}
          >
            <Globe size={18} color="#98D8AA" />
            <Text style={styles.websiteButtonText}>Visit Website</Text>
          </Pressable>
          
          <Animated.View
            entering={FadeInUp.duration(600).delay(600)}
            style={styles.section}
          >
            <Text style={styles.sectionTitle}>Our Technology</Text>
            <Text style={styles.technologyText}>{company.technology}</Text>
          </Animated.View>
          
          {company.metrics && (
            <Animated.View
              entering={FadeInUp.duration(600).delay(800)}
              style={styles.section}
            >
              <Text style={styles.sectionTitle}>Key Metrics</Text>
              
              <View style={styles.metricsContainer}>
                <View style={styles.metricCard}>
                  <View style={[styles.iconContainer, styles.iconYield]}>
                    <BarChart size={20} color="#10B981" />
                  </View>
                  <Text style={styles.metricLabel}>Yield</Text>
                  <Text style={styles.metricValue}>{company.metrics.yield}</Text>
                </View>
                
                <View style={styles.metricCard}>
                  <View style={[styles.iconContainer, styles.iconLocations]}>
                    <Building2 size={20} color="#8B5CF6" />
                  </View>
                  <Text style={styles.metricLabel}>Facilities</Text>
                  <Text style={styles.metricValue}>{company.metrics.facilities}</Text>
                </View>
              </View>
            </Animated.View>
          )}
          
          {company.products && (
            <Animated.View
              entering={FadeInUp.duration(600).delay(1000)}
              style={styles.section}
            >
              <Text style={styles.sectionTitle}>Products</Text>
              <Text style={styles.productsText}>{company.products}</Text>
            </Animated.View>
          )}
        </Animated.View>
      </Animated.ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  errorText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 18,
    color: '#EF4444',
    marginBottom: 16,
  },
  backButton: {
    backgroundColor: '#98D8AA',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  backButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 16,
    color: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 32,
  },
  header: {
    position: 'absolute',
    top: 48,
    left: 16,
    zIndex: 10,
  },
  backButtonContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  companyHeader: {
    position: 'relative',
  },
  heroImage: {
    width: '100%',
    height: 200,
  },
  companyLogo: {
    position: 'absolute',
    bottom: -40,
    left: 16,
    width: 80,
    height: 80,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    padding: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 8,
  },
  companyInfo: {
    marginTop: 48,
    padding: 16,
  },
  companyName: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#333333',
    marginBottom: 8,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  locationText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#808080',
    marginLeft: 8,
  },
  companyDescription: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
    marginBottom: 24,
  },
  websiteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#EBF9F1',
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginBottom: 24,
  },
  websiteButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#98D8AA',
    marginLeft: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 12,
  },
  technologyText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  metricCard: {
    flex: 1,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginRight: 8,
    alignItems: 'center',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconYield: {
    backgroundColor: '#ECFDF5',
  },
  iconLocations: {
    backgroundColor: '#F3F0FF',
  },
  metricLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  metricValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333333',
  },
  productsText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666666',
    lineHeight: 24,
  },
});