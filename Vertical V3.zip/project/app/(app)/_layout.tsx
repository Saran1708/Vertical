import { Stack } from 'expo-router';
import { useAuth } from '@/context/AuthContext';

export default function AppLayout() {
  const { user } = useAuth();
  
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
        contentStyle: { backgroundColor: '#FFFFFF' }
      }}
    >
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="crop/[id]" />
      <Stack.Screen name="company/[id]" />
      <Stack.Screen name="faq" />
    </Stack>
  );
}