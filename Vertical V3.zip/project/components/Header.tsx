import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Platform } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { ChevronDown, User, Settings, LogOut, CircleHelp as HelpCircle } from 'lucide-react-native';
import { Link, router } from 'expo-router';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withTiming, 
  withSpring,
  FadeIn,
  FadeOut 
} from 'react-native-reanimated';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function Header({ title }: { title?: string }) {
  const { user, signOut } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuAnimation = useSharedValue(0);

  const toggleMenu = () => {
    const newState = !isMenuOpen;
    setIsMenuOpen(newState);
    menuAnimation.value = withTiming(newState ? 1 : 0, { duration: 300 });
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
    menuAnimation.value = withTiming(0, { duration: 300 });
  };

  const menuStyle = useAnimatedStyle(() => {
    return {
      opacity: withTiming(menuAnimation.value, { duration: 200 }),
      transform: [
        { 
          translateY: withSpring(
            menuAnimation.value * 0 + (1 - menuAnimation.value) * -20
          )
        },
        { 
          scale: withSpring(
            menuAnimation.value * 1 + (1 - menuAnimation.value) * 0.9
          )
        }
      ],
    };
  });

  const iconStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { 
          rotate: `${menuAnimation.value * 180}deg` 
        }
      ],
    };
  });

  const handleNavigation = (route: string) => {
    closeMenu();
    router.push(route);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logoText}>GrowVert</Text>
      
      {title && <Text style={styles.title}>{title}</Text>}
      
      <View style={styles.profileContainer}>
        <Pressable onPress={toggleMenu} style={styles.profileButton}>
          <Text style={styles.profileText}>
            {user?.name?.split(' ')[0] || 'User'}
          </Text>
          <Animated.View style={iconStyle}>
            <ChevronDown size={20} color="#333333" />
          </Animated.View>
        </Pressable>
        
        {isMenuOpen && (
          <Animated.View 
            entering={FadeIn.duration(200)}
            exiting={FadeOut.duration(200)}
            style={[styles.backdrop]}
            onTouchStart={closeMenu}
          />
        )}
        
        {isMenuOpen && (
          <Animated.View style={[styles.menu, menuStyle]}>
            <AnimatedPressable 
              style={styles.menuItem}
              onPress={() => handleNavigation('/(app)/(tabs)/profile')}
            >
              <User size={18} color="#333333" />
              <Text style={styles.menuItemText}>Profile</Text>
            </AnimatedPressable>
            
            <AnimatedPressable 
              style={styles.menuItem}
              onPress={() => handleNavigation('/(app)/faq')}
            >
              <HelpCircle size={18} color="#333333" />
              <Text style={styles.menuItemText}>FAQ</Text>
            </AnimatedPressable>
            
            <View style={styles.divider} />
            
            <AnimatedPressable 
              style={[styles.menuItem, styles.logoutItem]}
              onPress={signOut}
            >
              <LogOut size={18} color="#EF4444" />
              <Text style={[styles.menuItemText, styles.logoutText]}>Logout</Text>
            </AnimatedPressable>
          </Animated.View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 48 : 16,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  logoText: {
    fontFamily: 'Poppins-Bold',
    fontSize: 20,
    color: '#98D8AA',
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333333',
    position: 'absolute',
    left: 0,
    right: 0,
    textAlign: 'center',
    zIndex: -1,
  },
  profileContainer: {
    position: 'relative',
  },
  profileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: 8,
  },
  profileText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333333',
    marginRight: 4,
  },
  backdrop: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 10,
  },
  menu: {
    position: 'absolute',
    top: 48,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 8,
    width: 200,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
    zIndex: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
  },
  menuItemText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#333333',
    marginLeft: 12,
  },
  divider: {
    height: 1,
    backgroundColor: '#F3F4F6',
    marginVertical: 8,
  },
  logoutItem: {
    marginTop: 4,
  },
  logoutText: {
    color: '#EF4444',
  },
});