import React, { createContext, useState, useContext, useEffect } from 'react';
import { router } from 'expo-router';

interface User {
  id: string;
  email: string;
  name: string;
  profileImage?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signOut: () => void;
  updateUserProfile: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on app load
  useEffect(() => {
    // Simulate checking for an existing session
    const checkSession = async () => {
      try {
        // For demo purposes, we'll just set loading to false
        // In a real app, you would check for a stored token or session
        setTimeout(() => {
          setIsLoading(false);
          // Navigate based on authentication status
          if (!user) {
            router.replace('/(auth)/login');
          }
        }, 1000);
      } catch (error) {
        setIsLoading(false);
        router.replace('/(auth)/login');
      }
    };

    checkSession();
  }, []);

  // Sign in function
  const signIn = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // In a real app, this would be an API call to your auth service
      // Simulate successful login after 1 second
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock user data for demo
      const userData: User = {
        id: '12345',
        email: email,
        name: 'John Doe',
        profileImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg'
      };
      
      setUser(userData);
      setIsLoading(false);
      router.replace('/(app)/(tabs)');
    } catch (error) {
      setIsLoading(false);
      throw new Error('Login failed. Please check your credentials and try again.');
    }
  };

  // Sign up function
  const signUp = async (name: string, email: string, password: string) => {
    setIsLoading(true);
    try {
      // In a real app, this would be an API call to your auth service
      // Simulate successful registration after 1 second
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Navigate to login screen after successful registration
      setIsLoading(false);
      router.replace('/(auth)/login');
    } catch (error) {
      setIsLoading(false);
      throw new Error('Registration failed. Please try again.');
    }
  };

  // Sign out function
  const signOut = () => {
    setUser(null);
    router.replace('/(auth)/login');
  };

  // Update user profile
  const updateUserProfile = (data: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...data });
    }
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        isLoading, 
        signIn, 
        signUp, 
        signOut,
        updateUserProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};