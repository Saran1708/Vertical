export const companies = [
  {
    id: '1',
    name: 'AeroFarms',
    location: 'Newark, New Jersey',
    description: 'AeroFarms is a leading vertical farming company that uses proprietary aeroponic technology to grow crops in fully-controlled environments without sun or soil, using 95% less water than traditional farming.',
    logo: 'https://images.pexels.com/photos/1084540/pexels-photo-1084540.jpeg',
    heroImage: 'https://images.pexels.com/photos/1084544/pexels-photo-1084544.jpeg',
    website: 'https://aerofarms.com',
    technology: 'AeroFarms uses a patented aeroponic growing system that mists the roots of plants with nutrients, water, and oxygen. Their approach uses 95% less water than traditional farming and yields up to 390 times more per square foot annually.',
    metrics: {
      yield: '390x traditional farming',
      facilities: '12+ global locations'
    },
    products: 'Leafy greens including kale, arugula, and microgreens distributed to major retailers across the United States.'
  },
  {
    id: '2',
    name: 'Plenty',
    location: 'San Francisco, California',
    description: 'Plenty is revolutionizing agriculture by growing flavorful, nutritious fruits and vegetables using vertical farming technology that requires a fraction of the land and water of conventional agriculture.',
    logo: 'https://images.pexels.com/photos/3735218/pexels-photo-3735218.jpeg',
    heroImage: 'https://images.pexels.com/photos/2749165/pexels-photo-2749165.jpeg',
    website: 'https://www.plenty.ag',
    technology: 'Plenty uses vertical plant towers and LED lighting to create the perfect environment for plants. Their farms can grow up to 350x more per acre than conventional farms while using 1% of the water.',
    metrics: {
      yield: '350x traditional farming',
      facilities: '4 major facilities'
    },
    products: 'Variety of leafy greens and strawberries, with plans to expand to other vine crops.'
  },
  {
    id: '3',
    name: 'Bowery Farming',
    location: 'New York City, New York',
    description: 'Bowery Farming is creating the world's most technologically advanced commercial indoor farming company to grow the highest quality produce imaginable, with a focus on sustainability and local production.',
    logo: 'https://images.pexels.com/photos/2284169/pexels-photo-2284169.jpeg',
    heroImage: 'https://images.pexels.com/photos/2284178/pexels-photo-2284178.jpeg',
    website: 'https://boweryfarming.com',
    technology: 'Bowery uses a proprietary operating system called BoweryOS that integrates software, hardware, sensors, computer vision systems, and robotics to monitor plants and automate many of the processes involved in indoor farming.',
    metrics: {
      yield: '100x more productive per square foot',
      facilities: '6 farms across the US'
    },
    products: 'Over 100 varieties of leafy greens, herbs, and root vegetables available in more than 850 stores.'
  },
  {
    id: '4',
    name: 'Gotham Greens',
    location: 'Brooklyn, New York',
    description: 'Gotham Greens is a global pioneer in urban greenhouse agriculture and a leading fresh produce and food company. Their climate-controlled, high-tech greenhouses grow leafy greens and herbs year-round.',
    logo: 'https://images.pexels.com/photos/4505167/pexels-photo-4505167.jpeg',
    heroImage: 'https://images.pexels.com/photos/2886937/pexels-photo-2886937.jpeg',
    website: 'https://www.gothamgreens.com',
    technology: 'Gotham Greens combines hydroponic growing techniques in controlled environment rooftop greenhouses with renewable energy. Their advanced irrigation systems recirculate water and capture rainwater.',
    metrics: {
      yield: '30x more productive than traditional farming',
      facilities: '9 greenhouse facilities spanning 9 states'
    },
    products: 'Premium quality lettuces, herbs, and pesto sauces distributed to retailers nationwide.'
  }
];