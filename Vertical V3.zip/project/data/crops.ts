export const crops = [
  {
    id: '1',
    name: 'Lettuce',
    scientificName: 'Lactuca sativa',
    shortDescription: 'Fast-growing leafy green ideal for hydroponics',
    description: 'Lettuce is one of the most popular crops for vertical farming due to its quick growth cycle and high market demand. It thrives in hydroponic systems and requires minimal space to grow.',
    image: 'https://images.pexels.com/photos/533360/pexels-photo-533360.jpeg',
    temperature: '60-70°F (15-21°C)',
    height: '6-12 inches',
    lifespan: '30-45 days',
    marketValue: 'High',
    origin: 'Mediterranean region',
    usage: 'Commonly used in salads, sandwiches, and as a versatile culinary ingredient. Lettuce is rich in vitamins A and K, and provides dietary fiber.',
    growingRequirements: {
      nutrients: 'Low to medium',
      water: 'Medium',
      light: '14-16 hours daily'
    }
  },
  {
    id: '2',
    name: 'Basil',
    scientificName: 'Ocimum basilicum',
    shortDescription: 'Aromatic herb with high market value',
    description: 'Basil is a fragrant herb that commands a premium price in the market. It grows exceptionally well in vertical farming systems and has a strong demand in culinary applications.',
    image: 'https://images.pexels.com/photos/5677628/pexels-photo-5677628.jpeg',
    temperature: '65-85°F (18-29°C)',
    height: '12-24 inches',
    lifespan: '3-4 months',
    marketValue: 'Very High',
    origin: 'India',
    usage: 'Essential in Italian cuisine, particularly for pesto, and widely used in Mediterranean and Asian dishes. Contains essential oils with antioxidant properties.',
    growingRequirements: {
      nutrients: 'Medium',
      water: 'Medium',
      light: '12-16 hours daily'
    }
  },
  {
    id: '3',
    name: 'Strawberries',
    scientificName: 'Fragaria × ananassa',
    shortDescription: 'Sweet berries with year-round demand',
    description: 'Strawberries adapt well to vertical farming techniques and allow for year-round production, which is especially valuable during off-season periods when prices are high.',
    image: 'https://images.pexels.com/photos/1045274/pexels-photo-1045274.jpeg',
    temperature: '60-80°F (15-26°C)',
    height: '8-12 inches',
    lifespan: '1-2 years (productive)',
    marketValue: 'High',
    origin: 'Europe and Americas (hybrid)',
    usage: 'Consumed fresh, in desserts, jams, and smoothies. Rich in vitamin C, manganese, and antioxidants with potential heart health benefits.',
    growingRequirements: {
      nutrients: 'Medium to high',
      water: 'Medium',
      light: '12-16 hours daily'
    }
  },
  {
    id: '4',
    name: 'Kale',
    scientificName: 'Brassica oleracea var. sabellica',
    shortDescription: 'Nutrient-dense leafy green with high demand',
    description: 'Kale is a nutritional powerhouse that has gained immense popularity in recent years. Its high nutritional content and market value make it an excellent crop for vertical farming.',
    image: 'https://images.pexels.com/photos/6316515/pexels-photo-6316515.jpeg',
    temperature: '55-75°F (13-24°C)',
    height: '12-24 inches',
    lifespan: '2-3 months',
    marketValue: 'High',
    origin: 'Eastern Mediterranean',
    usage: 'Used in salads, smoothies, and as a cooked green. Exceptionally rich in vitamins K, A, and C, with strong anti-inflammatory properties.',
    growingRequirements: {
      nutrients: 'High',
      water: 'Medium',
      light: '14-16 hours daily'
    }
  },
  {
    id: '5',
    name: 'Cherry Tomatoes',
    scientificName: 'Solanum lycopersicum var. cerasiforme',
    shortDescription: 'Compact variety ideal for vertical systems',
    description: 'Cherry tomatoes are compact, high-yielding crops that perform well in vertical systems. Their sweet flavor and versatility make them a popular choice for vertical farmers.',
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg',
    temperature: '65-85°F (18-29°C)',
    height: '3-6 feet (indeterminate)',
    lifespan: '4-6 months',
    marketValue: 'Medium to High',
    origin: 'South America',
    usage: 'Eaten fresh in salads, roasted as side dishes, or used in various culinary applications. Rich in lycopene, vitamins C and K.',
    growingRequirements: {
      nutrients: 'High',
      water: 'Medium to high',
      light: '14-18 hours daily'
    }
  },
  {
    id: '6',
    name: 'Spinach',
    scientificName: 'Spinacia oleracea',
    shortDescription: 'Fast-growing, nutrient-rich leafy green',
    description: 'Spinach grows quickly in vertical farms and has a high nutritional profile. It's in constant demand, making it a reliable crop for consistent revenue.',
    image: 'https://images.pexels.com/photos/2255925/pexels-photo-2255925.jpeg',
    temperature: '50-75°F (10-24°C)',
    height: '6-12 inches',
    lifespan: '30-45 days',
    marketValue: 'Medium to High',
    origin: 'Persia (modern Iran)',
    usage: 'Used in salads, smoothies, cooked dishes, and as a nutritional supplement. High in iron, vitamins A and C, and antioxidants.',
    growingRequirements: {
      nutrients: 'Medium',
      water: 'Medium',
      light: '12-16 hours daily'
    }
  }
];